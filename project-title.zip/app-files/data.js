var APP_DATA = {
  "scenes": [
    {
      "id": "0-test",
      "name": "test",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        }
      ],
      "faceSize": 256,
      "initialViewParameters": {
        "yaw": -0.017870462841035106,
        "pitch": -0.15469226024633365,
        "fov": 2.0943951023931953
      },
      "linkHotspots": [
        {
          "yaw": 1.4333705149643006,
          "pitch": -0.2713188900434371,
          "rotation": 0,
          "target": "1-test1"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "1-test1",
      "name": "test1",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 2048,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [],
      "infoHotspots": [
        {
          "yaw": 0,
          "pitch": 0,
          "title": "test",
          "text": "2222"
        }
      ]
    }
  ],
  "name": "Project Title",
  "settings": {
    "mouseViewMode": "drag",
    "autorotateEnabled": false,
    "fullscreenButton": true,
    "viewControlButtons": true
  }
};
